1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"buildId":"qt6cOUHRGr6Vt2tSneyg0","rsc":["$","$1","c",{"children":[["$","div",null,{"children":"Projects"}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"loading":null,"isPartial":false}
4:null
