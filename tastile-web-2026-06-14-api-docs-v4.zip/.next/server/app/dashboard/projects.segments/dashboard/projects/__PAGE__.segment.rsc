1:"$Sreact.fragment"
2:I[484,[],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"buildId":"_f2gvamd2thZRAZcZqNMT","rsc":["$","$1","c",{"children":[["$","div",null,{"children":"Projects"}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"loading":null,"isPartial":false}
4:null
