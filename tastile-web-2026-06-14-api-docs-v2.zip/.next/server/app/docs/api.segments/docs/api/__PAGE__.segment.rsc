1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"buildId":"EryLSfHm5WcRWkXs5dFf9","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-screen","children":[["$","script",null,{"id":"api-reference","type":"application/json","data-url":"/api/openapi"}],["$","script",null,{"src":"https://cdn.jsdelivr.net/npm/@scalar/api-reference"}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"loading":null,"isPartial":false}
4:null
