1:"$Sreact.fragment"
3:I[484,[],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"Rotz2wx0YMZnwj6wyQrA5","rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/dashboard/tiles?tab=changes;307;"}
