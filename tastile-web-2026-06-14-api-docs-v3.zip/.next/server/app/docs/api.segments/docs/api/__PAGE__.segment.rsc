1:"$Sreact.fragment"
2:I[484,[],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"buildId":"Rotz2wx0YMZnwj6wyQrA5","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-screen","children":[["$","script",null,{"id":"api-reference","type":"application/json","data-url":"/api/openapi"}],["$","script",null,{"src":"https://cdn.jsdelivr.net/npm/@scalar/api-reference"}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"loading":null,"isPartial":false}
4:null
