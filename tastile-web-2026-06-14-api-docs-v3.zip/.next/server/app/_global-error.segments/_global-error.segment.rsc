1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
0:{"buildId":"Rotz2wx0YMZnwj6wyQrA5","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
